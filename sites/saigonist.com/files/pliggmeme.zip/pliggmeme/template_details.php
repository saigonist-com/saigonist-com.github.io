<?php
	$template_info['name'] = 'Pliggmeme'; // do not use the _ character. use - instead
	$template_info['desc'] = 'Pliggmeme is a free and simple Pligg template based on Silverbullet';
	$template_info['author'] = 'Runnertalk';
	$template_info['support'] = 'http://forums.pligg.com/';
	$template_info['version'] = 1.00;
	$template_info['designed_for_pligg_version'] = '1.00';
?>
