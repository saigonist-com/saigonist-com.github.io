------------------ ABOUT -------------------
PliggMeme was created and distributed for version 1.0 of Pligg. 

We will not support, under any condition, modifed versions of the PliggMeme template.  We will not support previous versions of Pligg and are not obligated to support future versions of Pligg,
nor are we obligated to support 1.0.

The Pliggmeme template comes with a very limited warranty. That being that it doesn't have one. 

You're completely responsible for any negative ramifications caused by this template. 

When uploading this template to your site, you understand that you're using modifed versions of modules, and this could affect your sites appearance and features. 

We suggest backing up your modules directory before you upload the template.

----------------- LICENSE ------------------

This work has been licensed under the Attribution-Noncommercial-Share Alike 3.0 Unported.
In short, you are free to share and remix this work under the following conditions:
     
    * You must attribute the work in the manner specified by the author or licensor (but not in any way that suggests that they endorse you or your use of the work).
    * You may not use this work for commercial purposes.
    * If you alter, transform, or build upon this work, you may distribute the resulting work only under the same or similar license to this one.
 
 --------------TOS-------------------------------
 
 You agree to all that is stated above.